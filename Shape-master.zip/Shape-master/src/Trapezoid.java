import java.awt.*;

public class Trapezoid extends Quadrilateral
{
    public Trapezoid( Point A, Point B, Point C, Point D, Color color )
    {
        //buildPointList arrages the points so that sides P1P2, P2P3, P3P4, and P4P1 do not intersect
        //super() calls the super classes constructor.  In this case, it takes a Point[]
        //since that is what buildPointArray returns
        super(A, B, C, D, color);//you can call a static method within super - but not a non-static one.

        checkValidity();
    }
    private static Point[] buildPointArray(Point A, Point B, Point C, Point D)
    {
        LineSeg l1 = new LineSeg(A,B);
        LineSeg l2 = new LineSeg(B,C);
        LineSeg l3 = new LineSeg(C,D);
        LineSeg l4 = new LineSeg(D,A);

        if (l1.intersects(l3)) //sides AB and CD intersect. switch B and C
        {
            return new Point[]{A,C,B,D};
        }
        else if (l2.intersects(l4)) //sides AD and BC intersect.  switch C and D
        {
            return new Point[]{A,B,D,C};
        }
        else //none of the sides intersect with current arrangement
            return new Point[]{A,B,C,D};
    }
    public void checkValidity()
    {

        super.checkValidity();  // call superclasses version of checkValidty to make sure this is a valid Quadrilateral

        Point[] points= buildPointArray(point('A'),point('B'),point('C'),point('D'));
        LineSeg AB = new LineSeg(points[0],points[1]);
        LineSeg BC = new LineSeg(points[1],points[2]);
        LineSeg CD = new LineSeg(points[2],points[3]);
        LineSeg DA = new LineSeg(points[3],points[0]);
        if(!(AB.parallelTo(CD)||BC.parallelTo(DA))){
            throw new IllegalArgumentException("No parallel sides");
        }
    }
}
