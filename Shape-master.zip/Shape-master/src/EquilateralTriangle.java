import java.awt.*;

/**
 * EquilateralTriangle
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class EquilateralTriangle extends Triangle
{

    /**
     * Constructor for objects of class EquilateralTriangle
     */
    public EquilateralTriangle(Point A, Point B, Point C, Color color)
    {
        super(A,B,C, color);
        //check Validity of Triangle.  Should not have any collinear points
        checkValidity();
    }
    @Override
    public void checkValidity()
    {
        super.checkValidity();  // call superclasses version of checkValidty to make sure points are distinct
        //if the points are co-linear, throw an Exception
        LineSeg AB = new LineSeg(point('A'),point('B'));
        LineSeg BC = new LineSeg(point('B'),point('C'));
        LineSeg CA = new LineSeg(point('C'),point('A'));
        if (AB.parallelTo(BC) || BC.parallelTo(CA) || AB.parallelTo(CA))
            throw new IllegalArgumentException("Error: Points are collinear");
        if(!(MathFunctions.doubleEquals(AB.length(),BC.length(),Point.EQUALITYDELTA)&&MathFunctions.doubleEquals(BC.length(),CA.length(),Point.EQUALITYDELTA))){
            throw new IllegalArgumentException("Error: Sides aren't equal");
        }
    }
}
